export const createdUsers = new Set();
export const defaultPoints = {
    ears: 30, eyes: 50, chin: 15, beard: 15, nose: 10,
    forehead: 10, cheeks: 10, mouth: 100, neck: 10,
    whiskers: 10, muzzle: 20, "mouth (open)": 1000, "neck (sweaty)": 30
};

export const userPartsMap = {};
export const totalScores = {};
export const clickCounts = {};