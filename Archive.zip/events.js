import { backButton, goBack, openMouthOptions, selectUser } from "./main.js";
export const events = () => {
    const helene = document.getElementById("helene");
    const jordi = document.getElementById("jordi");
    const pixie = document.getElementById("pixie");
    const mouthHelene = document.querySelector(".mouth-helene")
    const mouthJordi = document.querySelector(".mouth-jordi")
    // ---- EVENT LISTENERS --------------------------------------------------
    helene.addEventListener('click', () => selectUser('helene'));
    jordi.addEventListener('click', () => selectUser('jordi'));
    pixie.addEventListener('click', () => selectUser('pixie'));
    mouthHelene.addEventListener('click', () => openMouthOptions());
    mouthJordi.addEventListener('click', () => openMouthOptions());
    backButton.addEventListener('click', () => goBack());
    // Keyboard (for face parts):
    document.body.querySelectorAll('[role="button"]').forEach(el => {
        el.addEventListener('keydown', e => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                el.click();
            }
        });
    });
}